// Copyright (c) 2022 Damian Nowakowski. All rights reserved.

#include "NotionUnrealEditor.h"

void UNotionUnrealEditor::Init()
{
	// Put initialization code here
}


